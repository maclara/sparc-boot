#define IEEE32_OFFSET	0x3fc	/* silo patches the offset of second.b here */
